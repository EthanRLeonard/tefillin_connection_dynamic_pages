'use strict';
/*
 * config.js — all external endpoints and credentials in one place.
 *
 * Secrets are read from environment variables when present, with the values
 * supplied for this project as fallbacks so it runs out of the box. For a real
 * deployment, set BASEROW_TOKEN in the environment and delete the fallback.
 */

module.exports = {
  // Sheety — the Google-Sheet-backed data source (replaces the old data.js).
  // Each sheet/tab is one path segment under the project base.
  sheety: {
    base: process.env.SHEETY_BASE ||
      'https://api.sheety.co/def8a22c9a9c1d8802f064139a91dbd7/copyOfQrCodePageInfo',
    sheets: { tefillin: 'tefillin', magia: 'magia', sofer: 'sofer' },
  },

  // Baserow — where the photos live. The sheet stores the public file URLs,
  // so serving a page needs no Baserow call; these settings are used by
  // baserow.js for managing photos (upload) and for resolving a bare row
  // reference to a URL if a sheet cell ever contains one instead of a URL.
  baserow: {
    apiBase: 'https://api.baserow.io',
    token: process.env.BASEROW_TOKEN || 'kwhBs415hhlawfEjbchnrTswrhPKYeqL',
    databaseId: 458883,
    tables: { images: 1011504, magia: 1011579, sofer: 1011595 },
  },

  // How long (ms) to cache a fetched sheet in memory before re-fetching.
  // Sheety is rate-limited, so we don't hit it on every request. Set 0 to
  // disable caching.
  cacheTtlMs: Number(process.env.SHEET_CACHE_TTL_MS || 60000),
};
