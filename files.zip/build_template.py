#!/usr/bin/env python3
"""Turn the sample rendered page into a placeholder template.

Reads the byte-exact sample (CRLF preserved), performs a set of *unique*
substring replacements, and asserts each one fired the expected number of
times. The output `template.html` together with `data.js` reproduces the
original page byte-for-byte for item JG2CB07.
"""
import json, sys, re

SRC = "/mnt/user-data/uploads/sample_tefillinconnectionpage.html"

# Read raw bytes, decode utf-8, keep CRLF intact (they are literal \r\n chars).
html = open(SRC, "rb").read().decode("utf-8")
orig_len = len(html)

# ---- The exact image blocks (img + following noscript) ----
# Each main <img> is located by its unique class signature, then the block is
# taken from the <img ... start through the end of its paired </noscript>.
def block_by_class(sig):
    needle = 'class="' + sig + '"'
    i = html.index(needle)
    start = html.rindex('<img decoding="async"', 0, i)
    end = html.index("</noscript>", start) + len("</noscript>")
    return html[start:end]

IMG_SIG = {
    "@@IMG_SOFER@@":       "uagb-team__image-crop-circle lazyloaded",  # sofer photo
    "@@IMG_HERO@@":        "wp-image-824 lazyloaded",                  # big finished-tefillin figure
    "@@IMG_FINAL@@":       "wp-image-824 ls-is-cached lazyloaded",     # timeline final-check screenshot
    "@@IMG_FINAL_MAGIA@@": "wp-image-823 lazyloaded",                  # last-check magia photo
    "@@IMG_FC_MAGIA@@":    "wp-image-788 lazyloaded",                  # first-check magia photo
    "@@IMG_WC@@":          "wp-image-825 lazyload",                    # writing-complete screenshot
}
image_blocks = {ph: block_by_class(sig) for ph, sig in IMG_SIG.items()}

BLURB = ("Yehuda is an experienced sofer with 15 years in the field, "
         "specializing in the Arizal script and holding certification from "
         "Vaad Mishmeret STaM. Outside of his professional work, he is a "
         "dedicated member of a local evening kollel in Beit Shemesh, where "
         "he maintains a consistent schedule of learning Gemara and daily "
         "Halacha.")

# (old, new, expected_count)
REPL = [
    # ---- head / identifiers ----
    ("JG2CB07", "@@ID@@", 2),
    ("jg2cb07", "@@SLUG@@", 3),
    ("page-id-822", "page-id-@@WP_POST_ID@@", 1),
    ("?p=822", "?p=@@WP_POST_ID@@", 1),

    # ---- image blocks (must run before text edits inside them are attempted) ----
    (image_blocks["@@IMG_SOFER@@"],       "@@IMG_SOFER@@", 1),
    (image_blocks["@@IMG_HERO@@"],        "@@IMG_HERO@@", 1),
    (image_blocks["@@IMG_WC@@"],          "@@IMG_WC@@", 1),
    (image_blocks["@@IMG_FC_MAGIA@@"],    "@@IMG_FC_MAGIA@@", 1),
    (image_blocks["@@IMG_FINAL@@"],       "@@IMG_FINAL@@", 1),
    (image_blocks["@@IMG_FINAL_MAGIA@@"], "@@IMG_FINAL_MAGIA@@", 1),

    # ---- sofer text ----
    (">Yehuda F.</h4>", ">@@SOFER_NAME@@</h4>", 1),
    ('uagb-team__prefix">Beit Shemesh, Israel</span>',
     'uagb-team__prefix">@@SOFER_LOCATION@@, Israel</span>', 1),
    ('uagb-team__desc">' + BLURB + "</p>",
     'uagb-team__desc">@@SOFER_BLURB@@</p>', 1),

    # ---- basic information ----
    ("Last Checked: <strong>1/19/2026</strong>",
     "Last Checked: <strong>@@LAST_CHECKED@@</strong>", 1),
    ("Ktav: <strong>Arizal</strong>", "Ktav: <strong>@@KTAV@@</strong>", 1),
    ("Hand: <strong>Left</strong>", "Hand: <strong>@@HAND@@</strong>", 1),
    ("Battim: <strong>Gassos</strong>", "Battim: <strong>@@BATTIM@@</strong>", 1),

    # ---- materials ----
    ("Company: <strong>Neparstack</strong>",
     "Company: <strong>@@KLAF_COMPANY@@</strong>", 1),
    ("Hachsher: <strong><strong>Bedatz Eida HaChradus</strong></strong>",
     "Hachsher: <strong><strong>@@KLAF_HACHSHER@@</strong></strong>", 1),
    ("Company: <strong>Fedder</strong>",
     "Company: <strong>@@BATTIM_COMPANY@@</strong>", 1),
    ("Hechsher: <strong>Rabbi Klein</strong>",
     "Hechsher: <strong>@@BATTIM_HECHSHER@@</strong>", 1),
    ("Company: <strong>Malchut Dovid</strong>",
     "Company: <strong>@@RETZUOS_COMPANY@@</strong>", 1),
    ("Hechsher: <strong>Bedatz Beis Yosef </strong>&amp;<strong> European Kosher</strong>",
     "Hechsher: <strong>@@RETZUOS_HECHSHER@@</strong>", 1),
    ("<strong>Giddim<br></strong>Hechsher: <strong>Bedatz Eida HaChradus</strong>",
     "<strong>Giddim<br></strong>Hechsher: <strong>@@GIDDIM_HECHSHER@@</strong>", 1),

    # ---- timeline dates (inner + outer per article) ----
    ('uagb-timeline__inner-date-new">December 25, 2025</div>',
     'uagb-timeline__inner-date-new">@@WC_DATE@@</div>', 1),
    ('uagb-timeline__date-new">December 25, 2025</div>',
     'uagb-timeline__date-new">@@WC_DATE@@</div>', 1),
    ('uagb-timeline__inner-date-new">January 8, 2026</div>',
     'uagb-timeline__inner-date-new">@@FC_DATE@@</div>', 1),
    ('uagb-timeline__date-new">January 8, 2026</div>',
     'uagb-timeline__date-new">@@FC_DATE@@</div>', 1),
    ('uagb-timeline__inner-date-new">January 19, 2026</div>',
     'uagb-timeline__inner-date-new">@@FINAL_DATE@@</div>', 1),
    ('uagb-timeline__date-new">January 19, 2026</div>',
     'uagb-timeline__date-new">@@FINAL_DATE@@</div>', 1),
    ('uagb-timeline__date-new"></div>',
     'uagb-timeline__date-new">@@SHIP_DATE@@</div>', 1),
]

for old, new, exp in REPL:
    got = html.count(old)
    if got != exp:
        print(f"ASSERT FAIL: expected {exp} got {got} for: {old[:70]!r}")
        sys.exit(1)
    html = html.replace(old, new)

# Sanity: original dynamic literals should now be gone from the template.
for gone in ["JG2CB07", "Yehuda F.", "Neparstack", "Malchut Dovid",
             "December 25, 2025", "Avroham-Mordichai-Goldblatt"]:
    assert gone not in html, f"leftover literal: {gone}"

open("template.html", "wb").write(html.encode("utf-8"))

# Record the JG2CB07 image blocks (exact bytes) for the data layer.
ASSET_KEYS = {
    "@@IMG_SOFER@@":       "sofer_4441",          # sofer 4441 photo
    "@@IMG_FC_MAGIA@@":    "magia_goldblatt",      # first-check magia
    "@@IMG_FINAL_MAGIA@@": "magia_knapelmacher",   # last-check magia
    "@@IMG_WC@@":          "JG2CB07_wc",           # writing-complete screenshot
    "@@IMG_FINAL@@":       "JG2CB07_final",        # timeline final screenshot
    "@@IMG_HERO@@":        "JG2CB07_hero",         # hero figure (finished tefillin)
}
assets = {ASSET_KEYS[ph]: image_blocks[ph] for ph in ASSET_KEYS}
json.dump(assets, open("assets.json", "w"), ensure_ascii=False, indent=0)

placeholders = sorted(set(re.findall(r"@@[A-Z_]+@@", html)))
print("Template written:", len(html), "chars (orig", orig_len, ")")
print("Placeholders:", placeholders)
