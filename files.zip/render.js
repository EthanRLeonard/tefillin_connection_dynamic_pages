'use strict';
/*
 * render.js — turn a resolved view model into the final HTML page.
 *
 * The template is read once with its CRLF line endings intact. Each @@KEY@@
 * token is replaced by view[KEY] for every occurrence. Tokens are unique
 * sentinels and no replacement value contains another token, so replacement
 * order is irrelevant.
 *
 * Data now comes from the live Sheety/Baserow layer (data.js), so renderById
 * is async.
 */

const fs = require('fs');
const path = require('path');
const data = require('./data');

const TEMPLATE = fs.readFileSync(path.join(__dirname, 'template.html'), 'utf8');

const KEYS = [
  'ID', 'SLUG', 'WP_POST_ID',
  'SOFER_NAME', 'SOFER_LOCATION', 'SOFER_BLURB',
  'LAST_CHECKED', 'KTAV', 'HAND', 'BATTIM',
  'KLAF_COMPANY', 'KLAF_HACHSHER',
  'BATTIM_COMPANY', 'BATTIM_HECHSHER',
  'RETZUOS_COMPANY', 'RETZUOS_HECHSHER', 'GIDDIM_HECHSHER',
  'WC_DATE', 'FC_DATE', 'FINAL_DATE', 'SHIP_DATE',
  'IMG_SOFER', 'IMG_HERO', 'IMG_FINAL',
  'IMG_FINAL_MAGIA', 'IMG_FC_MAGIA', 'IMG_WC',
];

function fill(view) {
  let html = TEMPLATE;
  for (const key of KEYS) {
    if (!(key in view)) throw new Error('view model missing key: ' + key);
    const token = '@@' + key + '@@';
    html = html.split(token).join(view[key] == null ? '' : String(view[key]));
  }
  const leftover = html.match(/@@[A-Z_]+@@/);
  if (leftover) throw new Error('unfilled placeholder: ' + leftover[0]);
  return html;
}

// renderById(id) -> HTML string, or null if the id is unknown. Async because
// it pulls live data.
async function renderById(id) {
  const view = await data.resolve(id);
  if (!view) return null;
  return fill(view);
}

module.exports = { renderById, fill };
