'use strict';
/*
 * baserow.js — thin client for the Baserow "Klaf Data" database where the
 * photos are stored.
 *
 * The Google Sheet already contains the public file URLs for every photo, so
 * rendering a page does NOT require any call here. This module exists so the
 * system can (a) manage photos in Baserow and (b) resolve a bare row/file
 * reference to a URL if a sheet cell ever holds one instead of a full URL.
 *
 * All endpoints and shapes follow the database's auto-generated API docs.
 * Table ids: images 1011504, magia 1011579, sofer 1011595.
 */

const config = require('./config');

const fetchImpl = (...args) =>
  (globalThis.fetch ? globalThis.fetch(...args)
    : Promise.reject(new Error('global fetch unavailable (need Node 18+)')));

function authHeaders(extra) {
  return Object.assign(
    { Authorization: 'Token ' + config.baserow.token },
    extra || {}
  );
}

// GET a single row (user_field_names=true -> human field names).
async function getRow(tableId, rowId) {
  const url = config.baserow.apiBase +
    '/api/database/rows/table/' + tableId + '/' + rowId +
    '/?user_field_names=true';
  const res = await fetchImpl(url, { headers: authHeaders() });
  if (!res.ok) throw new Error('baserow getRow ' + tableId + '/' + rowId +
    ' -> ' + res.status);
  return res.json();
}

// List rows in a table (paginated; returns the results array of page 1 by
// default). Pass { page, size } to page through.
async function listRows(tableId, opts) {
  const o = opts || {};
  const qs = new URLSearchParams({ user_field_names: 'true' });
  if (o.page) qs.set('page', String(o.page));
  if (o.size) qs.set('size', String(o.size));
  const url = config.baserow.apiBase +
    '/api/database/rows/table/' + tableId + '/?' + qs.toString();
  const res = await fetchImpl(url, { headers: authHeaders() });
  if (!res.ok) throw new Error('baserow listRows ' + tableId + ' -> ' + res.status);
  return res.json();
}

// Pull the first file URL out of a Baserow "file" field value (an array of
// file objects, per the docs).
function firstFileUrl(fieldValue) {
  if (Array.isArray(fieldValue) && fieldValue[0] && fieldValue[0].url) {
    return fieldValue[0].url;
  }
  return null;
}

// Upload a photo to Baserow by giving it a URL to download (upload-via-url).
// Returns the file object you can then attach to a row's file field.
async function uploadViaUrl(fileUrl) {
  const url = config.baserow.apiBase + '/api/user-files/upload-via-url/';
  const res = await fetchImpl(url, {
    method: 'POST',
    headers: authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ url: fileUrl }),
  });
  if (!res.ok) throw new Error('baserow uploadViaUrl -> ' + res.status);
  return res.json();
}

module.exports = {
  getRow,
  listRows,
  firstFileUrl,
  uploadViaUrl,
  tables: config.baserow.tables,
};
