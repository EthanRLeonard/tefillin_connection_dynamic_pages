'use strict';
/*
 * data.js — the normalized data store behind the API.
 *
 * It mirrors the three sheets of QR_code_page_info.xlsx:
 *   - sofers   (sheet "sofer")
 *   - magias   (sheet "magia")
 *   - tefillin (sheet "tefillin")
 *
 * Each tefillin record points at a sofer (by id) and at two magia checkers
 * (first-check + last-check), exactly as the spreadsheet's foreign keys do.
 * resolve(id) joins those records into the flat 27-field view model that
 * render.js drops into template.html.
 *
 * Image markup: WordPress emits a bulky <img>+<noscript> block per image
 * (responsive srcset, lazy-load placeholder, etc.). The six exact blocks
 * from the rendered sample live in assets.json and are referenced by key so
 * the JG2CB07 page round-trips byte-for-byte. Shared photos (a sofer's
 * portrait, a magia's portrait) are reused across items, just like the DB.
 */

const fs = require('fs');
const path = require('path');

const assets = JSON.parse(
  fs.readFileSync(path.join(__dirname, 'assets.json'), 'utf8')
);

// ---------------------------------------------------------------------------
// buildImageBlock — generate a WordPress-style img+noscript block for items
// whose exact rendered markup we don't have on hand (everything except the
// canonical JG2CB07 assets). Kept structurally faithful; used only for the
// j321hl7 schema-demonstration record.
// ---------------------------------------------------------------------------
function buildImageBlock(opts) {
  const { src, cls, width, height, style } = opts;
  const dims = (width ? ' width="' + width + '"' : '') +
               (height ? ' height="' + height + '"' : '');
  const styleAttr = style ? ' style="' + style + '"' : '';
  return (
    '<img decoding="async"' + dims +
    ' src="' + src + '" alt=""' + styleAttr +
    ' class="' + cls + '" />' +
    '<noscript><img decoding="async"' + dims +
    ' src="' + src + '" alt=""' + styleAttr +
    ' class="' + cls + '" /></noscript>'
  );
}

// ---------------------------------------------------------------------------
// sheet "sofer"
// ---------------------------------------------------------------------------
const sofers = {
  '4441': {
    id: '4441',
    name: 'Yehuda F.',
    location: 'Beit Shemesh',           // rendered as "{location}, Israel"
    blurb:
      'Yehuda is an experienced sofer with 15 years in the field, ' +
      'specializing in the Arizal script and holding certification from ' +
      'Vaad Mishmeret STaM. Outside of his professional work, he is a ' +
      'dedicated member of a local evening kollel in Beit Shemesh, where ' +
      'he maintains a consistent schedule of learning Gemara and daily ' +
      'Halacha.',
    klafCompany: 'Neparstack',
    klafHachsher: 'Bedatz Eida HaChradus',
    photoHtml: assets.sofer_4441,       // exact extracted block
  },
};

// ---------------------------------------------------------------------------
// sheet "magia"  (the checkers)
// ---------------------------------------------------------------------------
const magias = {
  '4194': {
    id: '4194',
    name: 'Rabbi Avroham Mordichai Goldblatt',
    photoHtml: assets.magia_goldblatt,  // exact extracted block
  },
  '4431': {
    id: '4431',
    name: 'Rabbi Avraham Mordechai Leyzerovitz',
    photoHtml: buildImageBlock({
      src: 'https://tefillinconnection.org/wp-content/uploads/2026/leyzerovitz-150x150.png',
      cls: 'wp-image-823 lazyloaded',
      width: 150, height: 150,
    }),
  },
  // Knapelmacher checked JG2CB07 but is absent from the magia sheet; given a
  // synthetic id so the join still works. Uses the exact extracted block.
  '9001': {
    id: '9001',
    name: 'Rabbi Yitzchak Knapelmacher',
    photoHtml: assets.magia_knapelmacher,
  },
};

// ---------------------------------------------------------------------------
// sheet "tefillin"  (one record per QR page)
// Dates are stored DD/MM/YYYY exactly as the spreadsheet supplies them.
// ---------------------------------------------------------------------------
const tefillin = {
  JG2CB07: {
    id: 'JG2CB07',
    wpPostId: '822',
    soferId: '4441',
    ktav: 'Arizal',
    hand: 'L',
    battim: 'Gassos',
    battimCompany: 'Fedder',
    battimHachsher: 'Rabbi Klein',
    retzuosCompany: 'Malchut Dovid',
    retzuosHachsher: 'Bedatz Beis Yosef & European Kosher',
    giddimHachsher: 'Bedatz Eida HaChradus',
    writingCompleteDate: '25/12/2025',
    firstCheckDate: '08/01/2026',
    firstCheckMagiaId: '4194',
    finalCheckDate: '19/01/2026',
    lastCheckMagiaId: '9001',
    shipDate: '',                       // shipped article: no date yet
    // exact extracted screenshot/figure blocks
    heroImageHtml: assets.JG2CB07_hero,
    finalImageHtml: assets.JG2CB07_final,
    wcImageHtml: assets.JG2CB07_wc,
  },

  // ---- schema-demonstration record from the xlsx "tefillin" sheet ----
  j321hl7: {
    id: 'j321hl7',
    wpPostId: '900',
    soferId: '4441',                    // same sofer -> photo reused
    ktav: 'Arizal',
    hand: 'R',
    battim: 'Gassos',
    battimCompany: 'Fedder',
    battimHachsher: 'Rabbi Klein',
    retzuosCompany: 'Malchut Dovid',
    retzuosHachsher: 'Bedatz Beis Yosef & European Kosher',
    giddimHachsher: 'Bedatz Eida HaChradus',
    writingCompleteDate: '18/03/2026',
    firstCheckDate: '30/03/2026',
    firstCheckMagiaId: '4194',          // Goldblatt -> photo reused
    finalCheckDate: '15/04/2026',
    lastCheckMagiaId: '4431',           // Leyzerovitz -> generated photo
    shipDate: '',
    heroImageHtml: buildImageBlock({
      src: 'https://tefillinconnection.org/wp-content/uploads/2026/25467-F.png',
      cls: 'wp-image-824 lazyloaded',
      style: 'border-radius:25px',
    }),
    finalImageHtml: buildImageBlock({
      src: 'https://tefillinconnection.org/wp-content/uploads/2026/25467-L.png',
      cls: 'wp-image-824 ls-is-cached lazyloaded',
      style: 'width:700px',
    }),
    wcImageHtml: buildImageBlock({
      src: 'https://tefillinconnection.org/wp-content/uploads/2026/25467-F.png',
      cls: 'wp-image-825 lazyloaded',
    }),
  },
};

// ---------------------------------------------------------------------------
// date helpers — input is DD/MM/YYYY
// ---------------------------------------------------------------------------
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

function parseDMY(s) {
  const [d, m, y] = s.split('/').map(Number);
  return { d, m, y };
}

// "December 25, 2025" (no leading zero on day)
function formatLong(dmy) {
  if (!dmy) return '';
  const { d, m, y } = parseDMY(dmy);
  return MONTHS[m - 1] + ' ' + d + ', ' + y;
}

// "1/19/2026" (M/D/YYYY, no leading zeros)
function formatShort(dmy) {
  if (!dmy) return '';
  const { d, m, y } = parseDMY(dmy);
  return m + '/' + d + '/' + y;
}

// hand code -> word
function handWord(code) {
  if (code === 'L') return 'Left';
  if (code === 'R') return 'Right';
  return code;
}

// "A & B" -> "A </strong>&amp;<strong> B" so the ampersand sits outside the
// surrounding <strong> the template provides. No " & " -> returned unchanged.
function ampSplit(value) {
  const parts = value.split(' & ');
  if (parts.length === 1) return value;
  return parts.join(' </strong>&amp;<strong> ');
}

// ---------------------------------------------------------------------------
// resolve(id) -> flat view model keyed by template placeholder name
// (without the @@ wrappers). Returns null for unknown ids.
// ---------------------------------------------------------------------------
function resolve(id) {
  const t = tefillin[id];
  if (!t) return null;

  const sofer = sofers[t.soferId];
  if (!sofer) throw new Error('unknown sofer ' + t.soferId + ' for ' + id);

  const fcMagia = magias[t.firstCheckMagiaId];
  const lastMagia = magias[t.lastCheckMagiaId];
  if (!fcMagia) throw new Error('unknown magia ' + t.firstCheckMagiaId);
  if (!lastMagia) throw new Error('unknown magia ' + t.lastCheckMagiaId);

  return {
    ID: t.id,
    SLUG: t.id.toLowerCase(),
    WP_POST_ID: t.wpPostId,

    SOFER_NAME: sofer.name,
    SOFER_LOCATION: sofer.location,
    SOFER_BLURB: sofer.blurb,

    LAST_CHECKED: formatShort(t.finalCheckDate),
    KTAV: t.ktav,
    HAND: handWord(t.hand),
    BATTIM: t.battim,

    KLAF_COMPANY: sofer.klafCompany,
    KLAF_HACHSHER: sofer.klafHachsher,
    BATTIM_COMPANY: t.battimCompany,
    BATTIM_HECHSHER: t.battimHachsher,
    RETZUOS_COMPANY: t.retzuosCompany,
    RETZUOS_HECHSHER: ampSplit(t.retzuosHachsher),
    GIDDIM_HECHSHER: t.giddimHachsher,

    WC_DATE: formatLong(t.writingCompleteDate),
    FC_DATE: formatLong(t.firstCheckDate),
    FINAL_DATE: formatLong(t.finalCheckDate),
    SHIP_DATE: formatLong(t.shipDate),

    // image blocks (exact bytes for JG2CB07; generated for demo items)
    IMG_SOFER: sofer.photoHtml,
    IMG_HERO: t.heroImageHtml,
    IMG_FINAL: t.finalImageHtml,
    IMG_FINAL_MAGIA: lastMagia.photoHtml,
    IMG_FC_MAGIA: fcMagia.photoHtml,
    IMG_WC: t.wcImageHtml,
  };
}

function knownIds() {
  return Object.keys(tefillin);
}

module.exports = {
  resolve,
  knownIds,
  sofers,
  magias,
  tefillin,
  // exported for tests/inspection
  _helpers: { formatLong, formatShort, handWord, ampSplit },
};
