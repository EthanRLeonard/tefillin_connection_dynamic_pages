'use strict';
/*
 * data.js — the live data layer. Replaces the old on-disk tables AND the
 * on-disk assets.json image blocks.
 *
 * Source of truth:
 *   - Sheety (Google Sheet) for tefillin / magia / sofer rows.
 *   - Photos live in Baserow; the sheet carries their public file URLs, so we
 *     build each <img> block from the URL the sheet gives us. Nothing about a
 *     page is read from disk.
 *
 * resolve(id) is async (it fetches the sheets) and returns the same flat
 * 27-key view model render.js expects. Sheets are cached in memory for a short
 * TTL so we don't hammer Sheety on every request.
 *
 * fetch is injectable via _setFetchImpl() so the logic can be tested without
 * network access.
 */

const config = require('./config');

let fetchImpl = (...args) =>
  (globalThis.fetch ? globalThis.fetch(...args)
    : Promise.reject(new Error('global fetch unavailable (need Node 18+)')));

function _setFetchImpl(fn) { fetchImpl = fn; }

// ---------------------------------------------------------------------------
// Sheety fetch + tiny TTL cache
// ---------------------------------------------------------------------------
const cache = new Map(); // sheetName -> { at, rows }

async function fetchSheet(name) {
  const ttl = config.cacheTtlMs;
  const hit = cache.get(name);
  if (hit && ttl > 0 && Date.now() - hit.at < ttl) return hit.rows;

  const url = config.sheety.base + '/' + config.sheety.sheets[name];
  const res = await fetchImpl(url);
  if (!res.ok) throw new Error('sheety ' + name + ' -> ' + res.status);
  const json = await res.json();
  const rows = json[name] || [];
  cache.set(name, { at: Date.now(), rows });
  return rows;
}

function clearCache() { cache.clear(); }

// ---------------------------------------------------------------------------
// image block builder — turns a photo URL into the WordPress-style
// <img>+<noscript> markup each slot expects, preserving the classes/styles
// that drive the page's CSS. (Exact responsive srcset variants don't exist for
// an arbitrary Baserow image, so a single src is used.)
// ---------------------------------------------------------------------------
const DATA_GIF =
  'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

// slot -> structural attributes mirrored from the original rendered page
const SLOTS = {
  sofer:      { cls: 'uagb-team__image-crop-circle lazyloaded',
                attrs: ' height="100" width="100" loading="lazy"' },
  final:      { cls: 'wp-image-824 ls-is-cached lazyloaded', style: 'width: 700px;' },
  hero:       { cls: 'wp-image-824 lazyloaded', style: 'border-radius:8px' },
  wc:         { cls: 'wp-image-825 lazyload', style: 'width: 7000px;', lazyPlaceholder: true },
};

function buildImageBlock(url, slotName) {
  const s = SLOTS[slotName];
  if (!s) throw new Error('unknown image slot ' + slotName);
  if (!url) return ''; // no photo -> render nothing for that slot

  const styleAttr = s.style ? ' style="' + s.style + '"' : '';
  const extra = s.attrs || '';
  const mainSrc = s.lazyPlaceholder ? DATA_GIF : url;
  const baseCls = s.cls.replace(/\blazyloaded\b|\blazyload\b|\bls-is-cached\b/g, '').trim();

  return (
    '<img decoding="async" class="' + s.cls + '"' + styleAttr +
    ' src="' + mainSrc + '" data-src="' + url + '" alt=""' + extra + '>' +
    '<noscript><img decoding="async" class="' + (baseCls || s.cls) + '"' +
    styleAttr + ' src="' + url + '" alt=""' + extra + '></noscript>'
  );
}

// A sheet image cell already holds a full URL (into Baserow's storage). If a
// cell is empty, return ''. (Hook point: a bare Baserow reference could be
// resolved here via baserow.js.)
function photoUrl(cell) {
  if (typeof cell === 'string' && /^https?:\/\//i.test(cell)) return cell;
  return '';
}

// escape plain text for safe insertion into HTML
function htmlEscape(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// buildMagiaBlock — the checker bio shown in a timeline entry: a small framed
// photo on the left, then "checked by:", the magia's name, and their
// description as real (selectable) text. Built with inline-styled <span>s so
// it stays valid inside the timeline's <p> and renders consistently. Any
// missing piece (photo / name / description) is simply omitted.
function buildMagiaBlock(url, name, description) {
  const img = url
    ? '<img decoding="async" src="' + url + '" alt="" ' +
      'style="width:110px;height:auto;border-radius:8px;flex:0 0 auto" ' +
      'class="tc-magia__photo">'
    : '';
  const checkedBy =
    '<span style="display:block;font-size:0.95em;opacity:0.85">checked by:</span>';
  const nameSpan = name
    ? '<span class="tc-magia__name" style="display:block;font-weight:700;' +
      'font-size:1.15em;margin-top:2px">' + htmlEscape(name) + '</span>'
    : '';
  const descSpan = description
    ? '<span class="tc-magia__desc" style="display:block;margin-top:8px;' +
      'font-size:0.95em;line-height:1.5">' + htmlEscape(description) + '</span>'
    : '';
  return (
    '<span class="tc-magia" style="display:flex;align-items:center;gap:16px;' +
    'text-align:left;margin-top:8px">' + img +
    '<span style="display:block">' + checkedBy + nameSpan + descSpan +
    '</span></span>'
  );
}

// ---------------------------------------------------------------------------
// date / value helpers (input dates are DD/MM/YYYY, as the sheet supplies)
// ---------------------------------------------------------------------------
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

function parseDMY(s) {
  const [d, m, y] = String(s).split('/').map(Number);
  return { d, m, y };
}
function formatLong(s) {
  if (!s) return '';
  const { d, m, y } = parseDMY(s);
  if (!d || !m || !y) return '';
  return MONTHS[m - 1] + ' ' + d + ', ' + y;
}
function formatShort(s) {
  if (!s) return '';
  const { d, m, y } = parseDMY(s);
  if (!d || !m || !y) return '';
  return m + '/' + d + '/' + y;
}
function handWord(code) {
  if (code === 'L') return 'Left';
  if (code === 'R') return 'Right';
  return code || '';
}
function ampSplit(value) {
  const parts = String(value).split(' & ');
  if (parts.length === 1) return value;
  return parts.join(' </strong>&amp;<strong> ');
}

// Sheety column keys (camelCased from the sheet headers). The final-check
// columns contain a comma + ampersand, so they're accessed by exact string.
const K_FINAL_DATE = 'finalCheck,Close &SealDate';
const K_FINAL_IMAGE = 'finalCheck,Close &SealImage';

// ---------------------------------------------------------------------------
// load all three sheets and index them by their business keys
// ---------------------------------------------------------------------------
async function loadAll() {
  const [tef, mag, sof] = await Promise.all([
    fetchSheet('tefillin'), fetchSheet('magia'), fetchSheet('sofer'),
  ]);
  const magias = new Map(mag.map((r) => [String(r.magiaId), r]));
  const sofers = new Map(sof.map((r) => [String(r.soferId), r]));
  const tefillin = new Map(tef.map((r) => [String(r.itemId).toLowerCase(), r]));
  return { tefillin, magias, sofers };
}

// ---------------------------------------------------------------------------
// resolve(id) -> 27-key view model (async), or null if id unknown
// ---------------------------------------------------------------------------
async function resolve(id) {
  const { tefillin, magias, sofers } = await loadAll();
  const t = tefillin.get(String(id).toLowerCase());
  if (!t) return null;

  const sofer = sofers.get(String(t.sofer));
  if (!sofer) throw new Error('unknown sofer ' + t.sofer + ' for ' + t.itemId);
  const fcMagia = magias.get(String(t.firstCheckMagia));
  const lastMagia = magias.get(String(t.lastCheckMagia));
  if (!fcMagia) throw new Error('unknown magia ' + t.firstCheckMagia);
  if (!lastMagia) throw new Error('unknown magia ' + t.lastCheckMagia);

  const finalImageUrl = photoUrl(t[K_FINAL_IMAGE]);

  return {
    ID: t.itemId,
    SLUG: String(t.itemId).toLowerCase(),
    WP_POST_ID: String(t.wpPostId || t.lotId || ''),

    SOFER_NAME: sofer.name,
    SOFER_LOCATION: sofer.soferLocation,
    SOFER_BLURB: sofer.soferBlurb,

    LAST_CHECKED: formatShort(t[K_FINAL_DATE]),
    KTAV: t.ktav,
    HAND: handWord(t.hand),
    BATTIM: t.battim,

    KLAF_COMPANY: sofer.klafCompany,
    KLAF_HACHSHER: sofer.klafHachsher,
    BATTIM_COMPANY: t.battimCompany,
    BATTIM_HECHSHER: t.battimHachsher,
    RETZUOS_COMPANY: t.retzuosCompany,
    RETZUOS_HECHSHER: ampSplit(t.retzuosHachsher),
    GIDDIM_HECHSHER: t.giddimHachsher,

    WC_DATE: formatLong(t.writingCompleteDate),
    FC_DATE: formatLong(t.firstCheckDate),
    FINAL_DATE: formatLong(t[K_FINAL_DATE]),
    SHIP_DATE: formatLong(t.shipDate),

    // photos: built from the URLs the sheet carries (Baserow storage)
    IMG_SOFER: buildImageBlock(photoUrl(sofer.image), 'sofer'),
    IMG_HERO: buildImageBlock(finalImageUrl, 'hero'),
    IMG_FINAL: buildImageBlock(finalImageUrl, 'final'),
    IMG_FINAL_MAGIA: buildMagiaBlock(
      photoUrl(lastMagia.image), lastMagia.name, lastMagia.description),
    IMG_FC_MAGIA: buildMagiaBlock(
      photoUrl(fcMagia.image), fcMagia.name, fcMagia.description),
    IMG_WC: buildImageBlock(photoUrl(t.writingCompleteImage), 'wc'),
  };
}

// list of known item ids, from the live sheet
async function knownIds() {
  const rows = await fetchSheet('tefillin');
  return rows.map((r) => String(r.itemId));
}

module.exports = {
  resolve,
  knownIds,
  fetchSheet,
  loadAll,
  clearCache,
  _setFetchImpl,
  _helpers: { formatLong, formatShort, handWord, ampSplit, buildImageBlock, photoUrl },
};
