# Tefillin Connection — Page API

An HTTP API that reproduces a Tefillin Connection QR-code product page from an
item id. `GET /JG2CB07` returns the page **byte-for-byte identical** to the
WordPress-rendered original; other items render from the same template using
their own data.

```
GET /            -> list of known ids
GET /:id         -> rendered HTML page (200), byte-exact for JG2CB07
GET /:id (miss)  -> 404
```

## Run

```bash
node server.js          # listens on :3000 (set PORT to change)
node test.js            # correctness gates (byte-exact + schema render)
```

No dependencies — Node's built-in `http` only. Verified on Node 22.

## How it works

The rendered sample page is 99% static WordPress/Spectra markup. Only ~30 spots
change per item. `build_template.py` reads the sample once and replaces each of
those spots with an `@@TOKEN@@`, asserting that every replacement matches the
expected number of occurrences. The result is `template.html` (27 placeholder
tokens) plus `assets.json` (the six exact image blocks). At request time the
template is filled back in — so for JG2CB07 the output is the original bytes,
CRLF line endings included.

```
build_template.py   sample HTML  -> template.html + assets.json   (build step)
data.js             item id      -> 27-field view model           (the "database")
render.js           view model   -> filled HTML
server.js           GET /:id     -> HTTP response
test.js             byte-exact round-trip gate
```

### Data model (mirrors QR_code_page_info.xlsx)

Three normalized tables matching the spreadsheet's three sheets. A `tefillin`
record carries foreign keys to one `sofer` and two `magia` checkers, exactly
like the sheet.

| sheet      | table in `data.js` | key                     |
|------------|--------------------|-------------------------|
| `sofer`    | `sofers`           | Sofer ID (e.g. 4441)    |
| `magia`    | `magias`           | Magia ID (e.g. 4194)    |
| `tefillin` | `tefillin`         | Item ID (e.g. JG2CB07)  |

`resolve(id)` joins these into the flat view model `render.js` consumes.

### Where each field lands on the page

| Placeholder         | Source field                              | Page location / rule |
|---------------------|-------------------------------------------|----------------------|
| `@@ID@@`            | tefillin.Item ID                          | `<title>` + H1 "Tefillin ID: …" |
| `@@SLUG@@`          | Item ID, lowercased                       | oEmbed JSON/XML + canonical URL |
| `@@WP_POST_ID@@`    | WordPress post id                         | `page-id-NNN` body class + `?p=NNN` shortlink |
| `@@SOFER_NAME@@`    | sofer.Name                                | "Your Sofer" team block |
| `@@SOFER_LOCATION@@`| sofer.Sofer Location                      | rendered as "{location}, Israel" |
| `@@SOFER_BLURB@@`   | sofer.Sofer blurb                         | team description |
| `@@KTAV@@`          | tefillin.Ktav                             | Basic information |
| `@@HAND@@`          | tefillin.hand (`L`/`R`)                    | Basic info; `L`→Left, `R`→Right |
| `@@BATTIM@@`        | tefillin.battim                           | Basic information |
| `@@LAST_CHECKED@@`  | tefillin.Final Check date                 | Basic info; **M/D/YYYY**, no leading zeros |
| `@@KLAF_COMPANY@@`  | **sofer**.Klaf Company                    | Materials |
| `@@KLAF_HACHSHER@@` | **sofer**.Klaf Hachsher                   | Materials; wrapped in double `<strong>` |
| `@@BATTIM_COMPANY@@`| tefillin.Battim Company                   | Materials |
| `@@BATTIM_HECHSHER@@`| tefillin.Battim Hachsher                 | Materials |
| `@@RETZUOS_COMPANY@@`| tefillin.Retzuos Company                 | Materials |
| `@@RETZUOS_HECHSHER@@`| tefillin.Retzuos Hachsher               | Materials; `A & B` split so `&` sits outside the `<strong>` |
| `@@GIDDIM_HECHSHER@@`| tefillin.Giddim Hachsher                 | Materials |
| `@@WC_DATE@@`       | tefillin.Writing Complete date            | Timeline; **Month D, YYYY** (×2 divs) |
| `@@FC_DATE@@`       | tefillin.first check date                 | Timeline (×2 divs) |
| `@@FINAL_DATE@@`    | tefillin.Final Check date                 | Timeline (×2 divs) |
| `@@SHIP_DATE@@`     | (shipped date, currently empty)           | Timeline "Shipped to you" |
| `@@IMG_SOFER@@`     | sofer photo                               | team photo (circle crop) |
| `@@IMG_HERO@@`      | finished-tefillin photo                   | hero figure |
| `@@IMG_FINAL@@`     | final-check screenshot                    | timeline "Final Check, Close & Seal" |
| `@@IMG_FINAL_MAGIA@@`| last-check magia photo                   | timeline final-check checker |
| `@@IMG_FC_MAGIA@@`  | first-check magia photo                   | timeline first-check checker |
| `@@IMG_WC@@`        | writing-complete screenshot               | timeline "Writing Complete" |

Notes that matter for byte-exactness:

- **Klaf Company / Hachsher come from the SOFER record**, not the tefillin row.
- **Dates** are stored `DD/MM/YYYY` (as in the sheet). The page shows two
  formats: the timeline uses `Month D, YYYY`; "Last Checked" uses `M/D/YYYY`.
  Both drop leading zeros.
- **Retzuos Hechsher** with an ampersand renders as
  `…Yosef </strong>&amp;<strong> European…` — the `&` breaks out of the
  `<strong>`. `ampSplit` reproduces this; values without ` & ` pass through.
- **Images** are emitted as the full WordPress `<img>`+`<noscript>` block
  (responsive `srcset`, lazy-load placeholder). The six exact blocks for the
  canonical page live in `assets.json`; shared photos (a sofer's or magia's
  portrait) are reused across items.

### The two records

- **JG2CB07** — the canonical item. Every field and all six image blocks are
  the exact values from the sample, so the page round-trips byte-for-byte.
- **j321hl7** — the example row from the spreadsheet, included to show the
  template generalizes. It reuses sofer 4441's and magia Goldblatt's exact
  photos (same foreign keys) and generates plausible blocks for the rest.

## Adding a new item

1. Add the sofer to `sofers` and any checkers to `magias` if not present.
2. Add a `tefillin` record with the foreign keys, fields, and dates
   (`DD/MM/YYYY`).
3. Supply its image blocks. If you have the real WordPress markup, store it
   verbatim; otherwise `buildImageBlock(...)` produces a structurally faithful
   block from a URL + class.

That's it — `GET /<id>` then serves the page.

## Files

```
build_template.py   one-time: sample HTML -> template.html + assets.json
template.html       the page with 27 @@TOKEN@@ placeholders
assets.json         the 6 exact image blocks for JG2CB07
data.js             tables (sofers/magias/tefillin) + resolve(id)
render.js           fills the template
server.js           HTTP API
test.js             byte-exact + schema-render gates
```
