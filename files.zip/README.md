# Tefillin Connection — Page API (live data)

An HTTP API that renders a Tefillin Connection QR-code product page from an
item id. Data is pulled **live** from a Google Sheet (via Sheety); the photos
live in **Baserow** and the sheet carries their public URLs. Nothing about a
page is stored on disk anymore.

```
GET /            -> list of known ids (from the live sheet)
GET /:id         -> rendered HTML page (200)
GET /:id (miss)  -> 404
```

## Run

```bash
npm start            # node server.js, listens on :3000 (set PORT to change)
npm test             # verifies the data/render logic against captured payloads
```

Requires **Node 18+** (uses built-in `fetch`; tested on Node 22). No npm
dependencies. The running process needs outbound network access to
`api.sheety.co` (and `api.baserow.io` only if you use the photo-management
helpers in `baserow.js`).

## Where the data comes from

| Concern        | Source                                                        |
|----------------|---------------------------------------------------------------|
| Row data       | Sheety: `…/copyOfQrCodePageInfo/{tefillin,magia,sofer}`       |
| Photos         | Baserow storage; the sheet's image columns hold the file URLs |

`data.js` fetches the three sheets, joins each tefillin row to its sofer and
its two magia checkers, and builds the page's `<img>` blocks from the photo
URLs the sheet provides. A short in-memory cache (default 60s, `SHEET_CACHE_TTL_MS`)
keeps it from hitting Sheety on every request.

```
config.js   endpoints, Baserow token, table ids, cache TTL
data.js     live Sheety fetch + join + photo lookup -> 27-field view model
baserow.js  Baserow API helpers (list/get rows, upload photos)
render.js   fills template.html from the view model  (async)
server.js   the HTTP API                              (async)
template.html   the page with 27 @@TOKEN@@ placeholders
test.js     end-to-end check using captured live payloads (no network needed)
```

### Configuration / secrets

`config.js` reads from environment variables with working fallbacks:

- `BASEROW_TOKEN` — Baserow database token (only needed for `baserow.js`).
- `SHEETY_BASE` — override the Sheety project base URL.
- `SHEET_CACHE_TTL_MS` — sheet cache lifetime in ms (`0` disables caching).

For a real deployment, set `BASEROW_TOKEN` in the environment and remove the
fallback in `config.js`.

### Sheety field names

Sheety camelCases the sheet headers. The data layer reads, among others:
`itemId, sofer, ktav, hand, battim, battimCompany, battimHachsher,
retzuosCompany, retzuosHachsher, giddimHachsher, writingCompleteDate,
writingCompleteImage, firstCheckDate, firstCheckMagia, lastCheckMagia`, plus
two columns whose headers contain a comma + ampersand and so are read by their
exact keys: `"finalCheck,Close &SealDate"` and `"finalCheck,Close &SealImage"`.
Sofer rows use `soferId, image, name, soferLocation, soferBlurb, klafCompany,
klafHachsher`; magia rows use `magiaId, name, image, description`.

### Rendering rules preserved

- `hand` `L`/`R` -> Left/Right.
- Dates stored `DD/MM/YYYY`; timeline shows `Month D, YYYY`, "Last Checked"
  shows `M/D/YYYY` (both drop leading zeros).
- Klaf company/hechsher come from the **sofer** record.
- Retzuos Hechsher `A & B` renders with the `&` breaking out of the `<strong>`.
- Each magia (first-check and final-check) renders as a bio block: a small
  framed photo plus a "checked by:" label, the magia's `name`, and their
  `description` as real selectable text (not baked into an image).
- Photos render as WordPress-style `<img>`+`<noscript>` blocks that keep the
  classes/styles the page CSS relies on, with `src`/`data-src` pointing at the
  Baserow file URL.

## Adding a new id

Add a **row to the Google Sheet** (the `tefillin` tab), referencing an existing
`soferId` and two `magiaId`s (add those rows too if new). Put each photo in
Baserow and paste its file URL into the sheet's image columns. No code change
and **no server restart** — the new id is served within one cache interval
(default 60s; call `data.clearCache()` or set `SHEET_CACHE_TTL_MS=0` for
instant pickup).

You can also POST rows to Sheety directly (the project exposes POST on the
`tefillin` and `magia` tabs), and `baserow.js` can upload a photo to Baserow
from a URL via `uploadViaUrl(...)`.

## Notes

- `sample_j321hl7_rendered.html` is a rendered example produced from the live
  sheet contents (the one row currently in the sheet), for visual inspection.
- `build_template.py` / `assets.json` are the original one-time template build
  artifacts. The runtime no longer reads `assets.json` (photos come from the
  sheet); `template.html` is still the page skeleton and is the only build
  output the server needs. `data.js.local-backup` is the previous on-disk data
  layer, kept for reference.
- Live calls can't be exercised from a sandbox without network egress to those
  hosts; `npm test` proves the logic against the exact payloads the endpoints
  return today.
