'use strict';
/*
 * test.js — correctness gates.
 *
 * 1. PRIMARY: renderById('JG2CB07') must equal the uploaded sample page
 *    byte-for-byte (CRLF included). This is the whole point of the build.
 * 2. The schema-generality record (j321hl7) must render with no leftover
 *    placeholders and with its own joined-in sofer/magia/date values.
 */

const fs = require('fs');
const crypto = require('crypto');
const { renderById } = require('./render');

const SAMPLE = '/mnt/user-data/uploads/sample_tefillinconnectionpage.html';

function sha(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

let failures = 0;

// ---- 1. byte-exact round trip ----
const expected = fs.readFileSync(SAMPLE);              // raw bytes
const got = Buffer.from(renderById('JG2CB07'), 'utf8');

if (Buffer.compare(expected, got) === 0) {
  console.log('PASS  JG2CB07 byte-exact  (' + got.length + ' bytes, sha ' +
    sha(got).slice(0, 16) + ')');
} else {
  failures++;
  console.log('FAIL  JG2CB07 byte mismatch');
  console.log('  expected ' + expected.length + ' bytes, got ' + got.length);
  // locate first differing byte for diagnostics
  const n = Math.min(expected.length, got.length);
  let i = 0;
  while (i < n && expected[i] === got[i]) i++;
  const a = expected.slice(Math.max(0, i - 60), i + 60).toString('utf8');
  const b = got.slice(Math.max(0, i - 60), i + 60).toString('utf8');
  console.log('  first diff at byte ' + i);
  console.log('  expected: ...' + JSON.stringify(a) + '...');
  console.log('  got:      ...' + JSON.stringify(b) + '...');
}

// ---- 2. unknown id ----
if (renderById('NOPE') === null) {
  console.log('PASS  unknown id -> null');
} else {
  failures++;
  console.log('FAIL  unknown id should be null');
}

// ---- 3. schema-generality render ----
const demo = renderById('j321hl7');
if (demo && !/@@[A-Z_]+@@/.test(demo)) {
  const checks = [
    ['id in title/h1', /Tefillin ID: j321hl7/.test(demo)],
    ['lowercase slug', demo.includes('tefillinconnection.org/j321hl7/')],
    ['right hand', /Hand: <strong>Right<\/strong>/.test(demo)],
    ['final date long', demo.includes('April 15, 2026')],
    ['last checked short', /Last Checked: <strong>4\/15\/2026<\/strong>/.test(demo)],
    ['sofer reused', demo.includes('Yehuda F.')],
  ];
  const bad = checks.filter(([, ok]) => !ok);
  if (bad.length === 0) {
    console.log('PASS  j321hl7 renders (' + demo.length + ' bytes, all field checks)');
  } else {
    failures++;
    console.log('FAIL  j321hl7 field checks: ' +
      bad.map(([n]) => n).join(', '));
  }
} else {
  failures++;
  console.log('FAIL  j321hl7 has leftover placeholders or is null');
}

process.exit(failures ? 1 : 0);
