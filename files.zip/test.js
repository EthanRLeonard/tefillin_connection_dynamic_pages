'use strict';
/*
 * test.js — verifies the live data layer end to end WITHOUT network access by
 * injecting the exact payloads the three Sheety endpoints return today. (On a
 * real host with outbound network, the same code path hits Sheety for real.)
 */

const data = require('./data');
const { renderById } = require('./render');

// ---- captured live Sheety responses ----
const SHEETS = {
  tefillin: { tefillin: [{
    lotId: 28326, itemId: 'j321hl7', sofer: 4441, ktav: 'Arizal', hand: 'R',
    battim: 'Gassos', battimCompany: 'Fedder', battimHachsher: 'Rabbi Klein',
    retzuosCompany: 'Malchut Dovid',
    retzuosHachsher: 'Bedatz Beis Yosef & European Kosher',
    giddimHachsher: 'Bedatz Eida HaChradus',
    writingCompleteDate: '18/03/2026',
    writingCompleteImage: 'https://baserow-backend-production20240528124524339000000001.s3.amazonaws.com/user_files/ZXHwM45paalQ7qYaDvwq99npJVlqTuKi_369b80e2bdcd7382245173dfdc7fa034b1672758df4057b1d3979a2524fd10ee.png',
    firstCheckDate: '30/03/2026', firstCheckMagia: 4194,
    'finalCheck,Close &SealDate': '15/04/2026',
    'finalCheck,Close &SealImage': 'https://baserow-backend-production20240528124524339000000001.s3.amazonaws.com/user_files/fTDCqt1A3Qlld1dIKn5rOW0pI95uUQhG_6144050dc0717e9bc27798558638033254c729f689b769b08ca4f996f12c40b0.png',
    lastCheckMagia: 4431, id: 2,
  }] },
  magia: { magia: [
    { magiaId: 4194, name: 'Rabbi Avroham Mordichai Goldblatt',
      image: 'https://baserow-backend-production20240528124524339000000001.s3.amazonaws.com/user_files/K03Enz8fRZRo9endYGXtOoPP8uJe4dk9_30a9d771d344afe64b4656cb1082b0b00f4bdc225b9eb7385bbb4836573adae8.png', id: 2 },
    { magiaId: 4431, name: 'Rabbi Avraham Mordechai Leyzerovitz',
      image: 'https://baserow-backend-production20240528124524339000000001.s3.amazonaws.com/user_files/m17gGbiq00YqW5PkBVaQkR0bCHElyuBU_ac75a98fb221323460b592ff10c14ff237ed0f1287d4743eab908c7bdc9be959.png', id: 3 },
  ] },
  sofer: { sofer: [{
    soferId: 4441,
    image: 'https://baserow-backend-production20240528124524339000000001.s3.amazonaws.com/user_files/dzIkHAtWeKT0KdItQMUjUwKp6RRa7NQ9_2c7788e4aa71affd973bb49bd6838af49e67fdee559942dc0d2ccf656a37d61b.png',
    name: 'Yehuda F.', soferLocation: 'Beit Shemesh',
    soferBlurb: 'Yehuda is an experienced sofer with 15 years in the field, specializing in the Arizal script and holding certification from Vaad Mishmeret STaM. Outside of his professional work, he is a dedicated member of a local evening kollel in Beit Shemesh, where he maintains a consistent schedule of learning Gemara and daily Halacha.',
    klafCompany: 'Neparstack', klafHachsher: 'Bedatz Eida HaChradus', id: 2,
  }] },
};

// mock fetch: pick the payload by which sheet name the URL ends with
data._setFetchImpl(async (url) => {
  const name = ['tefillin', 'magia', 'sofer'].find((n) => url.endsWith('/' + n));
  if (!name) throw new Error('unexpected url ' + url);
  return { ok: true, status: 200, json: async () => SHEETS[name] };
});

let failures = 0;
function check(label, cond) {
  console.log((cond ? 'PASS  ' : 'FAIL  ') + label);
  if (!cond) failures++;
}

(async () => {
  const view = await data.resolve('j321hl7');
  check('resolve returns a view model', !!view);

  const html = await renderById('j321hl7');
  check('renders without leftover placeholders',
    !!html && !/@@[A-Z_]+@@/.test(html));

  // field checks
  check('id in title/h1', /Tefillin ID: j321hl7/.test(html));
  check('lowercase slug in canonical URL',
    html.includes('tefillinconnection.org/j321hl7/'));
  check('hand R -> Right', /Hand: <strong>Right<\/strong>/.test(html));
  check('final date long form', html.includes('April 15, 2026'));
  check('writing-complete date long form', html.includes('March 18, 2026'));
  check('first-check date long form', html.includes('March 30, 2026'));
  check('Last Checked short form', /Last Checked: <strong>4\/15\/2026<\/strong>/.test(html));
  check('sofer name joined in', html.includes('Yehuda F.'));
  check('klaf company from sofer', html.includes('Neparstack'));
  check('retzuos ampersand split',
    html.includes('Bedatz Beis Yosef </strong>&amp;<strong> European Kosher'));

  // photos come from the live Baserow URLs in the sheet, not from disk
  check('sofer photo URL used',
    html.includes('dzIkHAtWeKT0KdItQMUjUwKp6RRa7NQ9'));
  check('first-check magia photo (Goldblatt) used',
    html.includes('K03Enz8fRZRo9endYGXtOoPP8uJe4dk9'));
  check('last-check magia photo (Leyzerovitz) used',
    html.includes('m17gGbiq00YqW5PkBVaQkR0bCHElyuBU'));
  check('writing-complete screenshot used',
    html.includes('ZXHwM45paalQ7qYaDvwq99npJVlqTuKi'));
  check('final-check screenshot used (hero + timeline)',
    (html.match(/fTDCqt1A3Qlld1dIKn5rOW0pI95uUQhG/g) || []).length >= 2);
  check('no on-disk wp-content image URLs remain',
    !html.includes('wp-content/uploads/2026'));

  // unknown id
  data.clearCache();
  const miss = await renderById('NOPE');
  check('unknown id -> null', miss === null);

  console.log(failures ? ('\n' + failures + ' FAILED') : '\nALL PASSED');
  process.exit(failures ? 1 : 0);
})();
