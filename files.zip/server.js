'use strict';
/*
 * server.js — minimal zero-dependency HTTP API over the live data layer.
 *
 *   GET /            -> index: list of known ids (from the live sheet)
 *   GET /:id         -> the rendered Tefillin page for that id (200)
 *   GET /:id  (miss) -> 404
 *
 * Data is fetched live from Sheety (rows) + the Baserow photo URLs the sheet
 * carries, so the running process needs outbound network access to
 * api.sheety.co (and, only if you use baserow.js, api.baserow.io). Requires
 * Node 18+ for global fetch (tested on Node 22).
 */

const http = require('http');
const data = require('./data');
const { renderById } = require('./render');

const PORT = process.env.PORT || 3000;

function sendHtml(res, status, html) {
  const body = Buffer.from(html, 'utf8');
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=UTF-8',
    'Content-Length': body.length,
  });
  res.end(body);
}

function send404(res, msg) {
  sendHtml(res, 404,
    '<!doctype html><meta charset="utf-8"><title>404</title><h1>' +
    String(msg).replace(/[<&]/g, (c) => (c === '<' ? '&lt;' : '&amp;')) +
    '</h1>');
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method !== 'GET') {
      res.writeHead(405, { 'Content-Type': 'text/plain' });
      res.end('Method Not Allowed');
      return;
    }

    const urlPath = req.url.split('?')[0].replace(/\/+$/, '') || '/';

    if (urlPath === '/') {
      const ids = await data.knownIds();
      const links = ids
        .map((id) => '<li><a href="/' + id + '">' + id + '</a></li>')
        .join('');
      sendHtml(res, 200,
        '<!doctype html><meta charset="utf-8"><title>Tefillin pages</title>' +
        '<h1>Available Tefillin pages</h1><ul>' + links + '</ul>');
      return;
    }

    const id = urlPath.slice(1);
    if (id.includes('/')) { send404(res, 'Not found'); return; }

    const html = await renderById(id);  // case-insensitive in data.resolve
    if (html === null) { send404(res, 'Tefillin id not found: ' + id); return; }

    sendHtml(res, 200, html);
  } catch (err) {
    console.error('request error:', err);
    res.writeHead(502, { 'Content-Type': 'text/plain' });
    res.end('Upstream data error: ' + err.message);
  }
});

if (require.main === module) {
  server.listen(PORT, () => {
    console.log('Tefillin API listening on http://localhost:' + PORT);
    console.log('Data: live from Sheety; photos from Baserow URLs in the sheet.');
  });
}

module.exports = server;
