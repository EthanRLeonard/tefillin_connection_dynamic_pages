'use strict';
/*
 * server.js — minimal zero-dependency HTTP API.
 *
 *   GET /            -> index: list of known ids
 *   GET /:id         -> the rendered Tefillin page for that id (200)
 *                       byte-identical to the WordPress original
 *   GET /:id  (miss) -> 404
 *   anything else    -> 404
 *
 * The id is matched case-insensitively against the data store keys, so both
 * /JG2CB07 and /jg2cb07 resolve to the same page (the canonical id casing is
 * preserved inside the rendered HTML regardless).
 */

const http = require('http');
const data = require('./data');
const { renderById } = require('./render');

const PORT = process.env.PORT || 3000;

// case-insensitive lookup of the canonical id
function canonicalId(raw) {
  const want = decodeURIComponent(raw).toLowerCase();
  return data.knownIds().find((k) => k.toLowerCase() === want) || null;
}

function sendHtml(res, status, html) {
  const body = Buffer.from(html, 'utf8');
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=UTF-8',
    'Content-Length': body.length,
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method !== 'GET') {
    res.writeHead(405, { 'Content-Type': 'text/plain' });
    res.end('Method Not Allowed');
    return;
  }

  const urlPath = req.url.split('?')[0].replace(/\/+$/, '') || '/';

  if (urlPath === '/') {
    const links = data.knownIds()
      .map((id) => '<li><a href="/' + id + '">' + id + '</a></li>')
      .join('');
    sendHtml(res, 200,
      '<!doctype html><meta charset="utf-8"><title>Tefillin pages</title>' +
      '<h1>Available Tefillin pages</h1><ul>' + links + '</ul>');
    return;
  }

  const id = urlPath.slice(1);
  if (id.includes('/')) {            // only single-segment ids
    sendHtml(res, 404, '<!doctype html><meta charset="utf-8"><title>404</title><h1>Not found</h1>');
    return;
  }

  const canonical = canonicalId(id);
  if (!canonical) {
    sendHtml(res, 404,
      '<!doctype html><meta charset="utf-8"><title>404</title>' +
      '<h1>Tefillin id not found: ' +
      id.replace(/[<&]/g, (c) => (c === '<' ? '&lt;' : '&amp;')) + '</h1>');
    return;
  }

  sendHtml(res, 200, renderById(canonical));
});

if (require.main === module) {
  server.listen(PORT, () => {
    console.log('Tefillin API listening on http://localhost:' + PORT);
    console.log('Known ids: ' + data.knownIds().join(', '));
  });
}

module.exports = server;
